/**
 * Handles checking for updates. 
 */
package wdl.update;