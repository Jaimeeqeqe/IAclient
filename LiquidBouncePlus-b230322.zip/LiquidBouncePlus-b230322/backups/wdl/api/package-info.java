/**
 * <h1>World Downloader API</h1>
 * 
 * You can create extensions for this mod using the API.  Simply implement
 * some of the WDL interfaces, and then call {@link WDLApi#addWDLMod(IWDLMod)}.
 * 
 * Note that you do need to handle loading the mod yourself - use liteloader
 * or Minecraft Forge for that.
 */
package wdl.api;